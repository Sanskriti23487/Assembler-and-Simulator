R_op_code= {"add":"0110011","sub":"0110011","sll":"0110011","slt":"0110011",
"sltu":"0110011","xor":"0110011","srl":"0110011","or":"0110011","and":"0110011"}

I_op_code= {"lw":"0000011", "addi":"0010011", "sltiu":"0010011", "jalr":"1100111"}

S_op_code= {"sw":"0100011"}

B_op_code= {"beq":"1100011", "bne":"1100011","blt":"1100011",
"bge":"1100011", "bltu":"1100011", "bgeu":"1100011"}

U_op_code= {"lui":"0110111", "auipc": '0010111'}

J_op_code= {"jal":"1101111"}

# registers= {"zero":"00000", "ra":"00001","sp":"00010","gp":"00011","tp":"00100","t0":"00101",
# "t1":"00110","t2":"00111","s0":"01000","fp": "01000","s1": "01001", "a0":"01010", "a1": "01011",
# "a2":"01100", "a3": "01101", "a4":"01110", "a5": "01111", "a6": "10000", "a7":"10001",
# "s2": "10010", "s3":"10011", "s4":"10100","s5":"10101", "s6":"10110", "s7":"10111",
# "s8":"11000" ,"s9": "11001", "s10":"11010", "s11": "11011" ,         #error in count somewhere????
# "t3":"11100", "t4":"11101", "t5":"11110", "t6":"11111"}  

# function_list= {"R":"add","sub","sll","slt","sltu","xor","srl","or","and"],
# "I":"lw","addi","sltiu","jalr"], "S":"sw"], "B":"beq","bne","blt","bge","bltu","bgeu"],
# 'U':"lui","auipc"], "J":"jal"]}

def binary_to_decimal(binary_str, bits, is_twos_complement=True):
    """ Gives unsigned if given false as s3rd paramenter
    use true or skip that for number using 2's complement
    """
    val = int(binary_str, 2)
    if is_twos_complement and (val & (1 << (bits - 1))):  # If interpreting as 2's complement and the sign bit is set
        val -= (1 << bits)  # Compute the 2's complement  
    return val
def unsigned(num1, bits):
    return binary_to_decimal(decimal_to_binary(num1, bits-1), bits, False)

memory={}
for i in range(0,32):
    memory[4*i +65536]= 0
# memory[ 65548]= 256
def decimal_to_binary(decimal, num_bits):
    binary = bin(decimal & ((1 << num_bits) - 1))[2:]  # Mask to ensure the specified number of bits
    binary = '0' * (num_bits - len(binary)) + binary  # Pad with leading zeros if necessary
    return binary