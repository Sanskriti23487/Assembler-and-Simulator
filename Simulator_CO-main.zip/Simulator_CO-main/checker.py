f1= open("ans.txt")
f2= open("sol.txt")
t1= f1.read().split('\n')
t2= f2.read().split('\n')

for i in range(len(t2)):
    flag=(t1[i] in t2[i])
    if flag== False:
        print(t1[i-1])
        print(t2[i-1])
        print()
        print(t1[i])
        print(t2[i])
        print()
        
        break