from things import *
# from all_funcs import R_instruction, J_instruction, B_instruction, findLabel, U_instruction, S_instruction, I_instruction
import sys
# inputFile="s1.txt"


registers={"00000":0,"00001":0,"00010":256,"00011":0,"00100":0,"00101":0,"00110":0,"00111":0,
           "01000":0, "01001":0,"01010":0, "01011":0,
           "01100":0, "01101":0,"01110":0, "01111":0,
            "10000":0,"10001":0, "10010":0,"10011":0,"10100":0,"10101":0,"10110":0,"10111":0,
            "11000":0, "11001":0,"11010":0, "11011":0 ,"11100":0,"11101":0,"11110":0,"11111":0}  
inputFile=sys.argv[1]
outputFile= sys.argv[2]
file=open(inputFile,'r')
text=file.read()

text=text.split('\n')
file.close()
f1= open(outputFile,'w')

PC=0
count1=0
while PC<=128:
    count1+=1
    if count1>=49:
        break
    line= text[PC//4]
    line=line.strip()
    if line[-7:]=='1111111' or '00000000000000000000000001100011' in line  :  # halt  opcode= "1111111"
        registers["00000"]=0
        registers_output = " ".join([f"0b{decimal_to_binary(registers[decimal_to_binary(i, 5)], 32)}" for i in range(0, 32)])
        output = f"0b{decimal_to_binary(PC, 32)} {registers_output}\n"
        f1.write(output)
        break
    elif line[-7:] =="0110011":#in R_op_code.values()[0]: #pranshu
        PC+=4
        opcode = line[-7:]
        funct3 = line[-15:-12]
        funct7 = line[-32:-25]
        rs1 = line[-20:-15]
        rs2 = line[-25:-20]
        rd = line[-12:-7]
        # print(opcode)
        # print (funct3)
        # print(funct7)
        # print(rs1)
        # print(rs2)
        # print(rd)
        # if opcode == '0110011':  # R-type instruction opcode
        if funct3 == '000' and funct7 == '0000000':  # add
            registers[rd] = registers[rs1] + registers[rs2]
        elif funct3 == '000' and funct7 == '0100000':  # sub
            registers[rd] = registers[rs1] - registers[rs2]
        elif funct3 == '001' and funct7 == '0000000':  # sll
            registers[rd]= registers[rs1]<<binary_to_decimal(decimal_to_binary(registers[rs2],5),5,False)  
        elif funct3 == '010' and funct7 == '0000000':  # slt
            if registers[rs1] < registers[rs2]:
                registers[rd]=1

        elif funct3 == '011' and funct7 == '0000000':  # stlu
            if unsigned(registers[rs1],5) < unsigned(registers[rs2],5):
                registers[rd]=1
        elif funct3 == '100' and funct7 == '0000000':  # xor
            registers[rd]= registers[rs1] ^ registers[rs2]
        elif funct3 == '101' and funct7 == '0000000':  # srl
            registers[rd]= registers[rs1]>> unsigned(registers[rs2],5)
        elif funct3== "110" and funct7 == '0000000': #or
            registers[rd]= registers[rs1] | registers[rs2]
        elif funct3== "111" and funct7 == '0000000': #and
            registers[rd]= registers[rs1] & registers[rs2]
    # Add more R-type instructions as needed
        else:
            # Unsupported instruction
                pass

    elif line[-7:] in U_op_code.values(): # veer
         opcode = line[-7:]
         PC+=4

         if opcode == '0110111':  # lui
            imm = line[-32:-12]  # Extract the immediate value
            rd = line[-12:-7]  # Extract the destination register
            imm_value = binary_to_decimal(imm, 32)
            registers[rd] = imm_value << 12
         elif opcode == '0010111':  # auipc
            imm = line[-32:-12]  # Extract the immediate value
            rd = line[-12:-7]  # Extract the destination register
            imm_value = binary_to_decimal(imm, 32)
            registers[rd] = PC + (imm_value << 12) -4
         
    elif line[-7:] in S_op_code.values(): #satvik
         PC+=4
         imm= line[-32:-25]+ line[-12:-7]
         rs2= line[-25:-20]
         rs1= line[-20:-15]
         mem= registers[rs1]+ binary_to_decimal(imm,12)
         memory[mem]= registers[rs2]
            # S_instruction(text[line])
    elif line[-7:] in J_op_code.values(): #veer
        #  PC+=4
         imm= line[-32]+ line[-20:-12]+ line[-21]+line[-31:-21]
         rd=line[-12:-7]
         registers[rd]= PC+4
         PC+= binary_to_decimal(imm+"0", 21)
         PC= decimal_to_binary(PC,32)
         PC= PC[:-1]+"0"
        #  PC[-1]="0"
         PC = int(PC,2)
            # J_instruction(text[line])
    elif (line)[-7:] in B_op_code.values(): #satvik
        PC+=4
        imm=""
        rs1= line[-20:-15]
        rs2= line[-25:-20]
        imm= line[-32]+line[-8]+ line[ -31:-25]+ line[-12:-8] +"0" 
        imm= binary_to_decimal( imm, 13)
        func3= line [-15:-12]
        if func3== "000":  # beq
            if registers[rs1]==registers[rs2]:
                if rs1== "00000":
                    break  
                PC-=4                 
                PC+=imm
        elif func3== "001": #bneq
            if registers[rs1]!=registers[rs2]:
                PC-=4
                PC+=imm
        elif func3== "100": # blt
            if registers[rs1] < registers[rs2]:
                PC-=4
                PC+= imm
        elif func3== "101":  #bge
            if registers[rs1] >= registers[rs2]:
                PC-=4
                PC+= imm
        elif func3== "110":   # bltu
            if registers[rs1] < registers[rs2]:
                PC-=4
                PC+= imm
        elif func3== "111": # bgeu
            if registers[rs1] >= registers[rs2]:
                PC-=4
                PC+=imm
        else:
            pass
            # B_instruction(text[line])
    elif line[-7:] in I_op_code.values(): #sanskriti
         PC+=4
         funct3= line[-15:-12]
         rd= line[-12:-7]
         rs= line[-20:-15]
         imm= line[-32:-20]
         opcode= line[-7:]
         if opcode=="0000011" and funct3=="010": # lw
             registers[rd]= memory[registers[rs1]+ binary_to_decimal(imm,12)]
         elif opcode=="0010011" and funct3== "000": # addi
             registers[rd]= registers[rs]+ binary_to_decimal(imm, 12)
         elif opcode== "0010011" and funct3== "011": # sltiu
             if unsigned(registers[rs],13) < unsigned(imm,13):
                 registers[rd]= 1
         elif opcode== "1100111" and funct3=="000": #jalr
             registers[rd]= PC
             PC-=4
             PC= registers[rs]+ int(imm,2)
             PC= decimal_to_binary(PC,32)
             PC= PC[:-1]+"0"
            #  PC[-1]="0"
             PC = int(PC,2)
             
         pass
            # I_instruction(text[line])
    elif line[-7:] =="0000001":   # multiply
        rs2=line[-25:-20]
        rs1= line[-20:-15]
        rd= line[-12:-7]
        registers[rd]= binary_to_decimal(decimal_to_binary(registers[rs2]* registers[rs1],32),32)
    elif line[-7:]=="0000010":    #reset
        for i in registers.values():
            i=0
        registers["00010"]=256
    elif line[-7:]== "0000100":  #reverse
        rs1= line[-20:-15]
        rd= registers[-12:-7]
        registers[rd]= binary_to_decimal((decimal_to_binary(registers[rs1],32))[::-1],32)


    else: 
        break
    registers["00000"]=0
    registers_output = " ".join([f"0b{decimal_to_binary(registers[decimal_to_binary(i, 5)], 32)}" for i in range(0, 32)])
    output = f"0b{decimal_to_binary(PC, 32)} {registers_output}\n"
    f1.write(output)
    # print()
n=""
for i in (memory.keys()):
    mem_hex= format(i, f"0{8}X")
    n+=(f"0x{mem_hex.lower()}:0b{decimal_to_binary(memory[i],32)}\n")
f1.write(n)
f1.close()
