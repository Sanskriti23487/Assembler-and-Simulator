R_op_code= {"add":["0110011","000"],"sub":["0110011","000"],"sll":["0110011","001"],"slt":["0110011","010"],
"sltu":["0110011","011"],"xor":["0110011","100"],"srl":["0110011","101"],"or":["0110011","110"],"and":["0110011","111"]}

I_op_code= {"lw":["0000011","010"], "addi":["0010011","000"], "sltiu":["0010011","011"], "jalr":["1100111","000"]}

S_op_code= {"sw":["0100011","010"]}

B_op_code= {"beq":["1100011","000"], "bne":["1100011","001"],"blt":["1100011","100"],
"bge":["1100011","101"], "bltu":["1100011","110"], "bgeu":["1100011","111"]}

U_op_code= {"lui":"0110111", "auipc": '0010111'}

J_op_code= {"jal":"1101111"}

PC=0

function_list= {"R":["add","sub","sll","slt","sltu","xor","srl","or","and"],
"I":["lw","addi","sltiu","jalr"], "S":["sw"], "B":["beq","bne","blt","bge","bltu","bgeu"],
'U':["lui","auipc"], "J":["jal"]}


registers= {"zero":"00000", "ra":"00001","sp":"00010","gp":"00011","tp":"00100","t0":"00101",
"t1":"00110","t2":"00111","s0":"01000","fp": "01000","s1": "01001", "a0":"01010", "a1": "01011",
"a2":"01100", "a3": "01101", "a4":"01110", "a5": "01111", "a6": "10000", "a7":"10001",
"s2": "10010", "s3":"10011", "s4":"10100","s5":"10101", "s6":"10110", "s7":"10111",
"s8":"11000" ,"s9": "11001", "s10":"11010", "s11": "11011" ,         #error in count somewhere????
"t3":"11100", "t4":"11101", "t5":"11110", "t6":"11111"}                                        #Nvm someone pointed out error on slack

errors= {1:"Unknown instruction used", 2: "Unknown register used", 3:"Illegal immediate value",
4:"Virtual halt is missing"}
# function_list to process the ype of instruction from the input
# rest opcodes for each separate instruction set 