from dicts import function_list, PC
from all_funcs import R_instruction, J_instruction, B_instruction, findLabel, U_instruction, S_instruction, I_instruction
import sys
inputFile=sys.argv[1]
outputFile= sys.argv[2]
file=open(inputFile,'r')

text=file.read()
file.close()
file1= open(outputFile, 'w')
flag=False
text= text.split('\n')
haltCount=0
for line in text :
    if line!="":
        if ':' in line:
            line=line.split(':')[1]
        instruction_name=line
        instruction_name= instruction_name.split()
        flag=0
        for (key,val) in function_list.items():
            if instruction_name[0] in val:
                flag=1
                if key== "R":
                    file1.write(R_instruction(line))
                elif key== "I":
                    file1.write(I_instruction(line,text))
                elif key== "S":
                    file1.write(S_instruction(line)) 
                elif key== "B":
                    if line=="beq zero,zero,0":
                        haltCount=1
                    file1.write(B_instruction(line, text))   
                elif key== "U":
                    file1.write(U_instruction(line)) 
                elif key== "J":
                    file1.write(J_instruction(line, text) )
                else:
                    raise Exception("Instruction not found")
                file1.write('\n')
                if flag==1:
                    PC+=4  
if haltCount==0:
    raise Exception("Virtual Halt not present")           
file1.close()  