def flip(val):
    return '1' if (val == '0') else '0'

def d2b(num):
    pbin = '{0:b}'.format(num)
    return pbin 

def twocomp(num,bits):
    if num >= 0:
        ans = d2b(num)
        return ans.zfill(bits)
    else:
        pnum = abs(num)
        neg = d2b(pnum)
        temp = 0
        for i in range(len(neg)-1,0,-1):
            if neg[i] == "1":
                temp = i
                break
            else:
                continue
        for j in range(0,temp):
            neg = neg[:j] + flip(neg[j]) + neg[j+1:]
        return neg.rjust(bits,"1")  

def binaryToDecimal(val_str, bits):

    val = int(val_str, 2)
    if (val & (1 << (bits - 1))) != 0:
        # If sign bit is set (negative value)
        val = val - (1 << bits)
    return val
        
def checkDigit(st):
    st=str(st)
    if st.isdigit():
        return True
    elif st[0]=='-' and st[1:].isdigit():
        return True
    else:
        return False    
            