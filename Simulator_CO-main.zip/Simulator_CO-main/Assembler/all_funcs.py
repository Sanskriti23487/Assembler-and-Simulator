from dicts import *
from conversions import *

labels={0:1}

def findLabel(startLine, allLines):
    count=0
    label=""
    label= (startLine.split(','))[-1]
    for i in range(len(allLines)):
        if startLine not in allLines[i]:
            continue
        count=i
        break
    i=0
    while ( i<len(allLines)):
        if allLines[i][:len(label)]== label:
            break
        i+=1
    if (i==len(allLines)):
        raise Exception("Label not used ")
    else:
        return 4*(i-count)

def R_instruction(line):            #done completely except errors
    output=""
    instruction= line.split()[0]
    if instruction=='sub':
        output="0100000"
    else:
        output="0000000"
    registers_index= (line.split()[1]).split(',')
    for r in registers_index[-1:0:-1]:
        if r not in registers.keys():
            raise Exception(f"{r} register not found")

        else:
            for key,val in registers.items():
                if key== r:
                    output+=val
                    break

    for ins in R_op_code.keys():
        if ins==instruction:
            output+= R_op_code[ins][1]

    rd= registers_index[0]
    if rd not in registers.keys():
        raise Exception(f"{rd} register not found")

    output+= registers[rd]    
    output+= "0110011"

    return output

def J_instruction(line,allLines):  #Done except errors
    global labels
    global PC
    r1= ((line.split())[1].split(','))[0]
    if r1 not in registers.keys():
        raise Exception(f"{r1} register not found")
    j_register= registers[r1] 
    labelName= ((line.split())[1].split(','))[-1]
    if labelName[-1]=='\n':
        labelName=labelName[:-1]
    if checkDigit(labelName):
        immBinary= twocomp(int(labelName),21)
    else:
        imm= findLabel(line, allLines )  #to get label's immediate value in decimal
        immBinary= twocomp(imm,21)  # to convert it to binary
        labels[(line.split(','))[-1]]= imm
    PC1= immBinary[0:-1]+'0'     #last bit to zero
    PC_temp= binaryToDecimal(PC1,21)  #converting the value to decimal
    PC+=PC_temp                       #add to PC the value
    output= f"{immBinary[-20]}{immBinary[-11:-1]}{immBinary[-11]}{immBinary[-20:-12]}{j_register}1101111"
    return output

def B_instruction(line,allLines):           #Done except halt and errors
    global PC
    global labels
    instruction_name=line.split()[0]
    registerNames=((line.split())[1].split(','))[0:2]
    labelName= (line.split(','))[-1]
    if labelName[-1]=='\n':
        labelName=labelName[:-1]
    if checkDigit(labelName):
        immBinary= twocomp(int(labelName),21)
    else:
        imm= findLabel(line ,allLines)
        immBinary= twocomp(imm,13)
        labels[(line.split(','))[-1]]= imm
    output= f"{immBinary[0]}{immBinary[-11:-5]}"

    for r in registerNames[::-1]:
        if r not in registers.keys():
            raise Exception(f"{r} register not found")
            
        else:
            output+=registers[r]
    if instruction_name not in B_op_code.keys():
        raise Exception(f"{instruction_name} instruction not found")
        
    output+= B_op_code[instruction_name][1]
    output+=f"{immBinary[-5:-1]}{immBinary[0]}"
    output+="1100011"
    return output
    
def U_instruction(line):
    components = line.split()
    opcode = components[0]
    if opcode not in U_op_code.keys():
        raise Exception("Instruction not found")

    destination_register = components[1].split(',')[0]

    if destination_register not in registers.keys():
        raise Exception("register not found")

    immediate = components[1].split(',')[1]
    immediate = int(immediate)
    if immediate>2**31 -1 or immediate< -(2**31):
        raise Exception("Immediate overflow")
    immediate_binary=twocomp(immediate,32)

    output=immediate_binary[0:20]
    output+=registers[destination_register]
    output+= U_op_code[opcode]
    return output

def S_instruction(line):
    output=''
    opcode='0100011'
    funct3='010'
    instruction=line.split()[0]
    rs2=(line.split()[1]).split(',')[0] 

    rs1= (line.split()[1]).split(',')[1].split('(')[1][:-1]
    imm = int(line.split()[1].split(',')[1].split('(')[0])
    if rs1 and rs2 in registers.keys():
        rs1binary=registers[rs1]
        rs2binary=registers[rs2]
    else:
        raise Exception("register not found")
    immbinary = twocomp(imm,12)
    output+=immbinary[0:7]
    output+=rs2binary
    output+=rs1binary
    output+=funct3
    output+=immbinary[7:]+opcode
    return output

def I_instruction(line, allLines):
    global PC
    global labels
    inst_name=line.split()[0]
    rd=line.split()[1].split(',')[0]
    rs=line.split()[1].split(',')[1]
    if inst_name=="lw":
        rs=line.split()[1].split(',')[1].split('(')[1][0:-1]
        imm= int(line.split()[1].split(',')[1].split('(')[0])
    else:
        imm=(line.split()[1].split(',')[2])
    if inst_name not in I_op_code.keys():
        raise Exception("Instruction name invalid")
    if rs not in registers.keys() :
        raise Exception(f"Register not found {rs}" )
    if rd not in registers.keys():
        raise Exception(f"Register not found {rd}" )
    if (checkDigit(imm)):
        imm=int(imm)
        if ((imm>2**11-1 or imm<-(2**11)) and inst_name!="sltiu"):
            raise Exception("Overflow")
        elif (inst_name=="sltiu" and (imm>2**12-1 or imm<-(2**12))):
            raise Exception("Overflow")
        immBinary= twocomp(imm,12)
    else:
        labelName=imm
        imm= findLabel(line,allLines)
        immBinary= twocomp(imm,12)  # to convert it to binary
        labels[labelName]= imm
    output= immBinary[:12]+registers[rs]
    output+= I_op_code[inst_name][1]+ registers[rd]+I_op_code[inst_name][0]
    return output